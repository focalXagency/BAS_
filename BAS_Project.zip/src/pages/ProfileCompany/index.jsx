
const ProfileCompany = () => {
  return (
    <div>
      profile
    </div>
  )
}

export default ProfileCompany
