import img from '../../assets/img/card.png'

export const ProductsData = [{
    title: 'SKIN',//title
    suppler: 'Super Skin Care',//suppler
    img: img,//img
    type: 'skin care',//type
},
{
    title: 'SKIN',
    suppler: 'Super Skin Care',
    img: img,
    type: 'skin care',
},
{
    title: 'NATURE',
    suppler: 'Super Skin Care',
    img: img,
    type: 'skin care',
},
{
    title: 'Foundation',
    suppler: 'Super Skin Care',
    img: img,
    type: 'foundation',
},
{
    title: 'CONDITIONER',
    suppler: 'Super Skin Care',
    img: img,
    type: 'conditioner',
},
{
    title: 'NATURE',
    suppler: 'Super Skin Care',
    img: img,
    type: 'skin care',
},
{
    title: "CONDITIONER",
    supplers: 'Best Conditioner',
    img: img,
    type: 'conditioner'
}
,
{
    title: "CONDITIONER",
    supplers: 'Best Conditioner',
    img: img,
    type: 'conditioner'
},
{
    title: "CONDITIONER",
    supplers: 'Best Conditioner',
    img: img,
    type: 'conditioner'
},
{
    title: "CONDITIONER",
    supplers: 'Best Conditioner',
    img: img,
    type: 'conditioner'
},
{
    title: "FOUNDATION",
    supplers: 'Nourish your skin',
    img: img,
    type: 'foundation'
},
{
    title: "FOUNDATION",
    supplers: 'Nourish your skin',
    img: img,
    type: 'foundation'
},
{
    title: "FOUNDATION",
    supplers: 'Nourish your skin',
    img: img,
    type: 'foundation'
},
{
    title: "FOUNDATION",
    supplers: 'Nourish your skin',
    img: img,
    type: 'foundation'
}

]