export  const Roles ={

    admin: 'Admin',
    user:'User',
}